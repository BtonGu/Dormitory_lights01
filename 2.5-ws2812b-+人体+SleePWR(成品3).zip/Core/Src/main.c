/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2021 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "dma.h"
#include "tim.h"
#include "gpio.h"
#include "ws2812b.h"
#include "rc522.h"
/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
void Encoder_Scan(void);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
uint8_t a=0;
//uint8_t cR=230,cG=140,cB=50;
uint8_t cR=50,cG=20,cB=10;
int16_t light=0xff;
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
  uint8_t RxBuffer[4];
	uint16_t Human=20;

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_TIM2_Init();
	MX_TIM3_Init();
	Usart_Init();
	SPI2_Init();
  /* USER CODE BEGIN 2 */
	HAL_TIM_Encoder_Start(&htim3,TIM_CHANNEL_ALL); TIM3->CNT = 0xff;
	ws2812_init(21);
  MFRC_Init();//��ʼ��
  PCD_Reset();//������λ
  /* USER CODE END 2 */
	
	
		ws2812_blue(21);
		HAL_Delay(700);
		ws2812_red(21);
		HAL_Delay(700);
		ws2812_green(21);
		HAL_Delay(700);
    ws2812_init(21);
	
	printf("Start\r\n");

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */
    
    /* USER CODE BEGIN 3 */
		
    if(HAL_GPIO_ReadPin(GPIOC,GPIO_PIN_0)==1){Human=1;printf("Human=1");}
		if(Human>=1){
			Human++;
			if(Human>=10){
				Human=0;
				MFRC_Init();//��ʼ��
        PCD_Reset();//������λ PCD_Reset();
				
				if(RxBuffer[0]==103){
					RxBuffer[0]=0;     //�ٿ�һ���ǲ���
					PCD_Request(PICC_REQALL, RxBuffer);PCD_Anticoll(RxBuffer);
			    PCD_Request(PICC_REQALL, RxBuffer);PCD_Anticoll(RxBuffer);
				}
				if(RxBuffer[0]!=103){
					ws2812_init(21);
					PCD_Request(PICC_REQALL, RxBuffer);PCD_Anticoll(RxBuffer);
			    PCD_Request(PICC_REQALL, RxBuffer);PCD_Anticoll(RxBuffer);
					if(RxBuffer[0]==103)ws2812_Simple(21,50,20,10);//RFID   ��һ�ε�
					Encoder_Scan();                                //ENcoder�����Ҳֻһ��
					printf("����˯��ģʽ\r\n");
					HAL_SuspendTick();
					HAL_PWR_EnterSLEEPMode(PWR_MAINREGULATOR_ON,PWR_SLEEPENTRY_WFI);
					HAL_ResumeTick();
				} 
			}
		}
		HAL_Delay(100);
		
		
	}
	
	

}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_PIN){
	if(GPIO_PIN==GPIO_PIN_0){
		printf("GPIO_EXTI_0\r\n");
		__HAL_GPIO_EXTI_CLEAR_IT(GPIO_PIN_0);
	}
}

void Encoder_Scan(void){
if(TIM3->CNT!=light){
			light= TIM3->CNT;
			printf("Ƶ��\r\n");
			cR=50+light-0xff;cG=cR-30;cB=cR-40;
      if(light<=255-10){
				cB=0;
			  if(light<=255-20){
					cG=0;
					if(light<=255-50)cR=0;
				}
			}
			ws2812_Simple(21,cR,cG,cB);
		}
}




/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
 // __disable_irq();
  printf("error");
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
