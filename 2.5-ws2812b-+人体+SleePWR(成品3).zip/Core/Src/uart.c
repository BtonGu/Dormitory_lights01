#include "main.h"

UART_HandleTypeDef UartHandle;
void Usart_Init(void)
{

  UartHandle.Instance        = USART1;
  UartHandle.Init.BaudRate   = 115200;//9600������ģ���
  UartHandle.Init.WordLength = UART_WORDLENGTH_8B;//8B=7+1(7��������)
  UartHandle.Init.StopBits   = UART_STOPBITS_1;
  UartHandle.Init.Parity     = UART_PARITY_NONE;
  UartHandle.Init.HwFlowCtl  = UART_HWCONTROL_NONE;
  UartHandle.Init.Mode       = UART_MODE_TX_RX;

  if (HAL_UART_Init(&UartHandle) != HAL_OK){Error_Handler();}
}

void HAL_UART_MspInit(UART_HandleTypeDef *huart)
{
  __HAL_RCC_GPIOA_CLK_ENABLE();  
  __HAL_RCC_USART1_CLK_ENABLE();
  //USARTx_CLK_ENABLE();

  
	GPIOA->CRH&=~(0xff0);
	GPIOA->CRH|= (0xBB0);
	GPIOA->ODR|=(3<<1);//PA 9 10
}

	
	
	
	
int fputc(int ch, FILE *f)	
{
  /* Place your implementation of fputc here */
  /* e.g. write a character to the USART1 and Loop until the end of transmission */
  HAL_UART_Transmit(&UartHandle, (uint8_t *)&ch, 1, 0xFFFF);

  return ch;
}

